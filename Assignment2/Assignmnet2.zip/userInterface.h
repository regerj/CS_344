#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <malloc.h>
#include <dirent.h>
// #include "dirent.h"
#include "Header.h"
#include "mem.h"

int choiceLoop();
bool choiceOne();
void choiceTwo();
