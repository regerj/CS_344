Compile the program using the command:
gcc --std=gnu99 -o movies_by_year main.c Header.h mem.c mem.h userInterface.c userInterface.h
It contains no memory leaks.
It is not portable accross operating systems, though I might add that feature to make debugging in my Windows Visual Studio IDE a little easier.
Thanks so much!